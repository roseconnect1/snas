class IRCClient {
    constructor(channel) {
        this.channel = channel;
        this.socket = null;
        this.username = null;
        this.usernameColor = null;
        
        this.chatContainer = document.getElementById('chat-container');
        this.messageInput = document.getElementById('message-input');
        this.sendBtn = document.getElementById('send-btn');
        
        this.usernameModal = document.getElementById('username-modal');
        this.usernameInput = document.getElementById('username-input');
        this.joinBtn = document.getElementById('join-btn');
        this.colorOptions = document.querySelectorAll('.color-options span');
        
        this.setupUsernameModal();
    }

    setupUsernameModal() {
        this.colorOptions.forEach(option => {
            option.addEventListener('click', () => {
                this.colorOptions.forEach(opt => opt.classList.remove('selected'));
                option.classList.add('selected');
                this.usernameColor = option.dataset.color;
            });
        });

        this.joinBtn.addEventListener('click', () => {
            const username = this.usernameInput.value.trim();
            if (username && this.usernameColor) {
                this.username = username;
                this.usernameModal.style.display = 'none';
                this.initializeWebSocket();
                this.setupEventListeners();
            } else {
                alert('Please choose a username and color');
            }
        });
    }

    initializeWebSocket() {
        this.socket = new WebSocket(`ws://${window.location.host}/`);

        this.socket.onopen = () => {
            this.socket.send(JSON.stringify({
                type: 'join',
                username: this.username,
                usernameColor: this.usernameColor,
                channel: this.channel
            }));
        };

        this.socket.onmessage = (event) => {
            const message = JSON.parse(event.data);
            this.displayMessage(message);
        };

        this.socket.onclose = () => {
            this.addSystemMessage('Disconnected from server');
        };
    }

    setupEventListeners() {
        this.sendBtn.addEventListener('click', () => this.sendMessage());
        this.messageInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.sendMessage();
        });
    }

    sendMessage() {
        const messageText = this.messageInput.value.trim();
        if (messageText) {
            this.socket.send(JSON.stringify({
                type: 'message',
                username: this.username,
                usernameColor: this.usernameColor,
                text: messageText,
                channel: this.channel
            }));
            this.messageInput.value = '';
        }
    }

    displayMessage(message) {
        const messageElement = document.createElement('div');
        messageElement.classList.add('message');

        if (message.type === 'system') {
            messageElement.classList.add('system-message');
            messageElement.textContent = message.text;
        } else {
            messageElement.classList.add('user-message');

            const usernameSpan = document.createElement('span');
            usernameSpan.classList.add('username');
            usernameSpan.textContent = `${message.username}: `;
            usernameSpan.style.color = message.usernameColor || '#e0e0e0';

            const messageTextSpan = document.createElement('span');
            messageTextSpan.textContent = message.text;

            messageElement.appendChild(usernameSpan);
            messageElement.appendChild(messageTextSpan);
        }

        this.chatContainer.insertBefore(messageElement, this.chatContainer.firstChild);
    }

    addSystemMessage(text) {
        this.displayMessage({
            type: 'system',
            text: text
        });
    }
}

const ircClient = new IRCClient('#leo-chat');