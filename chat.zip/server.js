const http = require('http');
const fs = require('fs');
const path = require('path');
const WebSocket = require('ws');

class IRCServer {
    constructor(port) {
        this.server = http.createServer((req, res) => {
            let filePath = path.join(__dirname, 'public', 
                req.url === '/' ? 'index.html' : req.url);
            
            const extname = path.extname(filePath);
            let contentType = 'text/html';
            
            switch (extname) {
                case '.css':
                    contentType = 'text/css';
                    break;
                case '.js':
                    contentType = 'text/javascript';
                    break;
            }
            
            fs.readFile(filePath, (error, content) => {
                if (error) {
                    if (error.code === 'ENOENT') {
                        res.writeHead(404);
                        res.end('404 - File Not Found');
                    } else {
                        res.writeHead(500);
                        res.end('Sorry, check with the site admin for error: '+error.code);
                    }
                } else {
                    res.writeHead(200, { 'Content-Type': contentType });
                    res.end(content, 'utf-8');
                }
            });
        });
        
        this.wss = new WebSocket.Server({ server: this.server });
        
        this.clients = new Set();

        this.setupEventHandlers();

        this.server.listen(port, '0.0.0.0', () => {
            console.log(`IRC Server running on port ${port}`);
        });
    }
    
    setupEventHandlers() {
        this.wss.on('connection', (ws) => {
            this.clients.add(ws);

            ws.on('message', (message) => {
                try {
                    const parsedMessage = JSON.parse(message);
                    this.handleMessage(ws, parsedMessage);
                } catch (error) {
                    console.error('Error parsing message:', error);
                }
            });

            ws.on('close', () => {
                this.clients.delete(ws);
                this.broadcastSystemMessage(`A user has left the chat`);
            });
        });
    }
    
    handleMessage(sender, message) {
        switch (message.type) {
            case 'join':
                this.broadcastSystemMessage(`${message.username} has joined the chat`);
                break;
            
            case 'message':
                this.broadcastMessage({
                    username: message.username,
                    text: message.text,
                    type: 'user'
                });
                break;
            
            default:
                console.log('Unknown message type:', message.type);
        }
    }
    
    broadcastMessage(message) {
        const serializedMessage = JSON.stringify(message);
        
        for (const client of this.clients) {
            if (client.readyState === WebSocket.OPEN) {
                client.send(serializedMessage);
            }
        }
    }
    
    broadcastSystemMessage(text) {
        this.broadcastMessage({
            type: 'system',
            text: text
        });
    }
}

const ircServer = new IRCServer(80);